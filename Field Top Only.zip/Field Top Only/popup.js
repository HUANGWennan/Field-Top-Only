document.addEventListener('DOMContentLoaded', () => {
  let isAIMode = false; // 状态标识
  
  // 模式切换逻辑
  const normalBtn = document.getElementById('normal-mode');
  const aiBtn = document.getElementById('ai-mode');
  const inputField = document.getElementById('keyword-input');

  function toggleMode(activeBtn) {
      [normalBtn, aiBtn].forEach(btn => btn.classList.remove('active'));
      activeBtn.classList.add('active');
      isAIMode = activeBtn === aiBtn;
      
      // 更新输入框提示
      inputField.placeholder = isAIMode ? "输入问题" : "输入关键词";
      document.getElementById('search-text').textContent = isAIMode ? "AI检索" : "开始搜索";
  }

  normalBtn.addEventListener('click', () => toggleMode(normalBtn));
  aiBtn.addEventListener('click', () => toggleMode(aiBtn));

   // 搜索逻辑
   document.getElementById('search').addEventListener('click', async () => {
    const keywords = inputField.value.trim();
    if (!keywords) {
        document.getElementById('status').textContent = "请输入内容！";
        return;
    }

    try {
        const { journals = [] } = await chrome.storage.sync.get('journals');
        if (journals.length === 0) throw new Error("请先配置期刊列表");

        // 根据模式生成不同URL
        journals.forEach(journal => {
            let baseURL = "https://www.citexs.com/allSearch?";
            const params = new URLSearchParams({
                query: keywords,
                journal: journal || ""
            });
            
            if (!isAIMode) params.append('select', '主题'); // 非AI模式添加参数
            
            chrome.tabs.create({ url: baseURL + params.toString() });
        });

        document.getElementById('status').textContent = 
            `已通过${isAIMode ? "AI" : "关键词"}检索${journals.length}个资源`;
        
    } catch (err) {
        document.getElementById('status').textContent = err.message;
    }
});

  // 设置按钮逻辑（保持不变）
  document.getElementById('settings-btn').addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
  });
});