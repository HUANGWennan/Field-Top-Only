// 默认期刊列表
const defaultJournals = [
  "Review of Radical Political Economics",
    "Metroeconomica",
    "Review of Keynesian Economics",
    "Journal of Economic Issues",
    "Journal of Post Keynesian Economics",
    "Cambridge Journal of Economics",
    "International Journal of Political Economy",
    "Review of Political Economy",
    "European Journal of Economics and Economic Policies",
    "Structural Change and Economic Dynamics",
    "International Review of Applied Economics",
    "Review of Social Economy",
    "The American Economic Review",
    "Journal of Economic Literature",
    "The Review of Economic Studies",
    "The Economic Journal",
  ""  // 空值用于全局搜索
];

// 初始化页面
document.addEventListener('DOMContentLoaded', () => {
  loadJournals();
  
  // 保存按钮
  document.getElementById('save').addEventListener('click', saveJournals);
  
  // 新增：恢复默认按钮
  document.getElementById('reset').addEventListener('click', () => {
      document.getElementById('journals').value = defaultJournals.join('\n');
      document.getElementById('status').textContent = '已恢复默认列表，请点击保存';
  });
});

// 加载期刊列表
function loadJournals() {
  chrome.storage.sync.get('journals', (data) => {
      document.getElementById('journals').value = 
          (data.journals && data.journals.length > 0) 
              ? data.journals.join('\n') 
              : defaultJournals.join('\n');
  });
}

// 保存期刊列表
function saveJournals() {
  const list = document.getElementById('journals').value
      .split('\n')
      .map(item => item.trim())
      .filter(item => item !== "");
  
  // 保留空行（全局搜索）
  if (document.getElementById('journals').value.includes('\n\n')) {
      list.push('');
  }

  chrome.storage.sync.set({ journals: list }, () => {
      document.getElementById('status').textContent = '保存成功！';
      setTimeout(() => {
          document.getElementById('status').textContent = '';
      }, 2000);
  });
}