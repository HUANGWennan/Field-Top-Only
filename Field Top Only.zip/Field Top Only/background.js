// 扩展安装时初始化数据
chrome.runtime.onInstalled.addListener(() => {
  const defaultJournals = [
    "Review of Radical Political Economics",
    "Metroeconomica",
    "Review of Keynesian Economics",
    "Journal of Economic Issues",
    "Journal of Post Keynesian Economics",
    "Cambridge Journal of Economics",
    "International Journal of Political Economy",
    "Review of Political Economy",
    "European Journal of Economics and Economic Policies",
    "Structural Change and Economic Dynamics",
    "International Review of Applied Economics",
    "Review of Social Economy",
    "The American Economic Review",
    "Journal of Economic Literature",
    "The Review of Economic Studies",
    "The Economic Journal",
  ""  // 空值用于全局搜索
  ];
  chrome.storage.sync.set({ journals: defaultJournals });
});